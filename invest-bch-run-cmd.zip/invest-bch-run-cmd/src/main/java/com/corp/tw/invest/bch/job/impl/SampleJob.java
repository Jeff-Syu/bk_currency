package com.corp.tw.invest.bch.job.impl;

import com.corp.tw.invest.bch.job.Job;

public class SampleJob extends Job {

  @Override
  public void beforeJob() {
    System.out.println("BeforeJob");
  }

  @Override
  public void process() {
    System.out.println("Process");
  }

  @Override
  public void sendNotification() {
    System.out.println("SendNotification");
  }

  @Override
  public void saveLog() {
    System.out.println("SaveLog");
  }

  @Override
  public void afterJob() {
    System.out.println("AfterJob");
  }
}
