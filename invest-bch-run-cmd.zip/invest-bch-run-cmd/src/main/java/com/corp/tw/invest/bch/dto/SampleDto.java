package com.corp.tw.invest.bch.dto;

import com.corp.tw.invest.bch.validation.annotation.field.SampleRule;
import javax.validation.constraints.NotNull;

public class SampleDto {

  @NotNull
  @SampleRule("param")
  private String sampleField;

  private  String sampleField2;

  public String getSampleField() {
    return sampleField;
  }

  public void setSampleField(String sampleField) {
    this.sampleField = sampleField;
  }

  public String getSampleField2() {
    return sampleField2;
  }

  public void setSampleField2(String sampleField2) {
    this.sampleField2 = sampleField2;
  }
}
