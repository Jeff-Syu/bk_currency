package com.corp.tw.invest.bch.mapper;

import com.corp.tw.invest.bch.base.utils.FieldMapper;
import com.corp.tw.invest.bch.dto.SampleDto;
import java.util.HashMap;
import java.util.Map;

public class SampleMapper<T> extends FieldMapper<T>{

  public SampleMapper(String separator, Class<T> clazz){
    super(separator, clazz);
  }

  public Map<String, Integer> getFieldMap() {
    Map<String, Integer> map = new HashMap<>();
    map.put("sampleField" , 0);
    map.put("sampleField2", 1);

    return map;
  }


  //  public SampleDto merge(String line){
//
//    String [] aryData = line.split(this.separator);
//
//    SampleDto sampleDto = new SampleDto();
//    sampleDto.setSampleField(this.getStr(aryData,0));
//    sampleDto.setSampleField2(this.getStr(aryData,1));
//
//    return sampleDto;
//  }

//  private String getStr(String [] aryData, Integer index){
//    return aryData[index];
//  }
}
