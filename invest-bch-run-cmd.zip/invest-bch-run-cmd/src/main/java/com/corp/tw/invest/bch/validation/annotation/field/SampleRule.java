package com.corp.tw.invest.bch.validation.annotation.field;


import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import com.corp.tw.invest.bch.validation.annotation.field.impl.SampleRuleValidator;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

@Target({FIELD, PARAMETER})
@Retention(RUNTIME)
@Documented
@Constraint(validatedBy = SampleRuleValidator.class)
public @interface SampleRule {

  //客製屬性
  String value() default "";


  //下列三個為Validation固定會呼叫的屬性務必要加上
  String message() default "Invalid";
  Class<?>[] groups() default {};
  Class<? extends Payload>[] payload() default {};
}
