package com.corp.tw.invest.bch.executor;

import com.corp.tw.invest.bch.job.Job;
import com.corp.tw.invest.bch.job.impl.SampleJob;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class JobExecutor implements ApplicationRunner {

  @Override
  public void run(ApplicationArguments args) throws Exception {
    Job job = new SampleJob();
    job.execute();
  }

}
