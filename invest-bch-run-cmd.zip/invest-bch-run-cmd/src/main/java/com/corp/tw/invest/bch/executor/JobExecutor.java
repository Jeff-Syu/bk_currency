package com.corp.tw.invest.bch.executor;

import com.corp.tw.invest.bch.base.utils.FieldMapper;
import com.corp.tw.invest.bch.dto.SampleDto;
import com.corp.tw.invest.bch.job.Job;
import com.corp.tw.invest.bch.job.impl.SampleJob;
import com.corp.tw.invest.bch.base.annotation.FieldValidator;
import com.corp.tw.invest.bch.mapper.SampleMapper;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class JobExecutor implements ApplicationRunner {

  @Autowired
  FieldValidator fieldValidator;

  @Override
  public void run(ApplicationArguments args) throws Exception {
    Job job = new SampleJob();
    job.execute();

    SampleMapper sampleMapper = new SampleMapper("@@", SampleDto.class);

    //FieldMapper fieldMapper = new FieldMapper(map, "@@", SampleDto.class);
    SampleDto s = (SampleDto) sampleMapper.merge("12@@,456");
    System.out.println(s.getSampleField());
    System.out.println(s.getSampleField2());
    //fieldValidator.validate(sampleDto);

  }
}
