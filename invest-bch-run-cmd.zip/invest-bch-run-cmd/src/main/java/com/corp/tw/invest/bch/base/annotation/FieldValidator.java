package com.corp.tw.invest.bch.base.annotation;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FieldValidator<T> {

  @Autowired
  Validator validator;

  public Set<ConstraintViolation<T>> validate(T dto){
    Set<ConstraintViolation<T>> validateSet = validator.validate(dto);

    return validateSet;
  }
}
