package com.corp.tw.invest.bch.base.utils;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Map.Entry;

public abstract class FieldMapper<T> {

  /**
   * 欄位資訊
   */
  private Map<String, Integer> fieldMap;

  /**
   * 分隔符號
   */
  private String separator;

  /**
   * 轉換物件的Class
   */
  private Class<T> clazz;

  public FieldMapper(String separator, Class<T> clazz){
    this.separator = separator;
    this.clazz = clazz;
  }

  public FieldMapper(Map<String, Integer> fieldMap ,String separator, Class<T> clazz){
    this.fieldMap = fieldMap;
    this.separator = separator;
    this.clazz = clazz;
  }


  public T merge(String line) throws Exception {
    String [] aryData = line.split(separator);
    T obj = clazz.getDeclaredConstructor().newInstance();
    for (Entry<String, Integer> entry : this.getFieldMap().entrySet()){
      Field field = obj.getClass().getDeclaredField(entry.getKey());
      field.setAccessible(true);
      field.set(obj, aryData[entry.getValue()]);
      field.setAccessible(false);
    }

    return obj;
  }

  protected abstract Map<String, Integer> getFieldMap();

}
