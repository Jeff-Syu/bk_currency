package com.corp.tw.invest.bch.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BatchConfig
{

}
