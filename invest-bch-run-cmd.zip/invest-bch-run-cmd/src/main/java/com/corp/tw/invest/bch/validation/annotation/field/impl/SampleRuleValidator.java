package com.corp.tw.invest.bch.validation.annotation.field.impl;

import com.corp.tw.invest.bch.validation.annotation.field.SampleRule;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class SampleRuleValidator implements ConstraintValidator<SampleRule, String> {

  private SampleRule sampleRule;

  /***
   * initialize 裡取得 annotation 的各個設定值
   * @param constraintAnnotation
   */
  @Override
  public void initialize(SampleRule constraintAnnotation) {
    ConstraintValidator.super.initialize(constraintAnnotation);
    this.sampleRule = constraintAnnotation;
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    //驗證結果
    boolean isValid =true;

    //邏輯處理
    System.out.println(sampleRule.value());

    return isValid;
  }
}
