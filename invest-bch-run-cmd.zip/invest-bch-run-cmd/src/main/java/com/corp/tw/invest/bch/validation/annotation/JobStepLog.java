package com.corp.tw.invest.bch.validation.annotation;

public @interface JobStepLog {
}
