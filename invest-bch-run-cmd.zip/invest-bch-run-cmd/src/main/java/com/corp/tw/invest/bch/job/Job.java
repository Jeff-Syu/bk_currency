package com.corp.tw.invest.bch.job;

import org.springframework.context.annotation.Primary;
import org.springframework.lang.NonNull;

public abstract class Job {
  /**
   * 排程執行前
   */
  protected abstract void beforeJob();

  /**
   * 排程過程
   */
  protected abstract void process();


  /**
   * 發送通知
   */
  protected abstract void sendNotification();

  /**
   * 紀錄排程歷程
   */
  protected abstract void saveLog();

  /**
   * 排程執行後
   */
  protected abstract void afterJob();

  /**
   * 執行排程
   */
  public void execute(){
    this.beforeJob();
    this.process();
    this.sendNotification();
    this.saveLog();
    this.afterJob();
  }
}
